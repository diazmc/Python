from __future__ import unicode_literals

from django.apps import AppConfig


class Login1AppConfig(AppConfig):
    name = 'login1_app'
